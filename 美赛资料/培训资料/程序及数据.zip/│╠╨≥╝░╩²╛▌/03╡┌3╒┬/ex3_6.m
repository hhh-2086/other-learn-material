x0=2;
[x,y]=fminsearch(@fun5,x0)

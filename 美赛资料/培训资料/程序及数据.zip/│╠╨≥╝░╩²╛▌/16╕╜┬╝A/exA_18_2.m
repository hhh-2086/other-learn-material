syms n
f2=1/n^2;
s2=symsum(f2,n,1,inf)

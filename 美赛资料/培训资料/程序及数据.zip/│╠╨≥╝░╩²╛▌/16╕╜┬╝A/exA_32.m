a=rand(5,10);
xlswrite('data5.xls',a,'Sheet2','B2')
